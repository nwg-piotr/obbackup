path_to_rc_xml = "/.config/openbox/rc.xml"
path_to_menu_xml = "/.config/openbox/menu.xml"
path_to_autostart = "/.config/openbox/autostart"
path_to_tint2rc = "/.config/tint2/tint2rc"

path_to_backup = None
backup_dir = "/.obbackup"

home = ""

backup_rc_xml = False
backup_menu_xml = False
backup_autostart = False
backup_tint2rc = False

output_filename_entry = None
input_filename_label = None

exists_rc_xml = False
exists_menu_xml = False
exists_autostart = False
exists_tint2rc = False

checkbox_restore_rc_xml = None
checkbox_restore_autostart = None
checkbox_restore_menu_xml = None
checkbox_restore_tint2rc = None

restore_path_display_field = None
restore_button = None
backup_button = None
